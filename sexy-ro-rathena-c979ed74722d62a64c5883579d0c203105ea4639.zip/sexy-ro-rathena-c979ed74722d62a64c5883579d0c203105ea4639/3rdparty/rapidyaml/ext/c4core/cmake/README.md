# cmake project utilities

Useful cmake scripts, at [c4Project.cmake](c4Project.cmake).

## Project utilities

## Adding targets

### Target types

## Downloading and configuring third-party projects at configure time

## Setting up tests

### Coverage
### Static analysis
### Valgrind

## Setting up benchmarks

## License

MIT License


